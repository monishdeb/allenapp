// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'Env.dart';

// **************************************************************************
// EnviedGenerator
// **************************************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// generated_from: .env
final class _Env {
  static const String DRUPAL_URL = 'drupaldemo.jmaconsulting.biz';

  static const String OAUTH_CLIENT_ID =
      'CQJAv7ojBhAmGvysQAIBbfaCpOl7esv03-a3EVPFYQc';

  static const List<int> _enviedkeyOAUTH_CLIENT_SECRET = <int>[
    374461828,
    3782403454,
    2560186342,
    2702829538,
    1645213903,
    2088047731,
    1919911656,
    896705298,
    1893504896,
    3425406869,
  ];

  static const List<int> _envieddataOAUTH_CLIENT_SECRET = <int>[
    374461901,
    3782403347,
    2560186245,
    2702829453,
    1645213857,
    2088047637,
    1919911581,
    896705377,
    1893504997,
    3425406961,
  ];

  static final String OAUTH_CLIENT_SECRET = String.fromCharCodes(
      List<int>.generate(
    _envieddataOAUTH_CLIENT_SECRET.length,
    (int i) => i,
    growable: false,
  ).map((int i) =>
          _envieddataOAUTH_CLIENT_SECRET[i] ^
          _enviedkeyOAUTH_CLIENT_SECRET[i]));
}
